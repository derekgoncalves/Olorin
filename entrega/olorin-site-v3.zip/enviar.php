<?php
/**
 * Olorin Digital — recebe o formulário de orçamento (PROMPT seção 10.4).
 *
 * GERADO PELO BUILD a partir de src/php/enviar.njk: as listas de serviços, faixas de investimento,
 * planos e páginas vêm do mesmo conteúdo do site (src/content/), para nunca ficarem diferentes.
 *
 *  1. Confere método, origem (Origin/Referer do próprio domínio) e anti-spam (isca e tempo mínimo)
 *  2. Valida e limpa os campos (sem quebra de linha em campos de uma linha; WhatsApp em +55DDDNÚMERO)
 *  3. Limita envios por IP (6 a cada 10 min) — contado só depois da validação
 *  4. Grava o pedido num CSV mensal FORA da pasta pública (../leads/AAAA-MM.csv), se possível
 *  5. Envia o aviso por e-mail via SMTP autenticado da Locaweb (e webhook opcional)
 *  6. Responde em JSON (envio pelo site) ou redireciona para /obrigado/ (navegador sem JavaScript)
 *
 * Configuração: ../olorin-config.php (fora do public_html) ou config.php (ao lado deste arquivo).
 * Modelo em config.example.php. Requer PHP 7.4 ou superior.
 */

date_default_timezone_set('America/Sao_Paulo');
header('X-Robots-Tag: noindex, nofollow');
header('Cache-Control: no-store');

$OLORIN_LISTAS = json_decode('{"servicos":["Tráfego pago","Redes sociais e conteúdo","Identidade visual e criação","Material impresso","Site ou loja virtual","Rastreamento e relatório","Ainda não sei, quero conversar"],"investimento":["Ainda não invisto","Até R$ 2 mil por mês","De R$ 2 a 5 mil por mês","De R$ 5 a 15 mil por mês","Acima de R$ 15 mil por mês"],"planos":["","pontual","gestao-mensal","360-completo"],"slugs":["","trafego-pago","redes-sociais","identidade-visual","material-impresso","site-e-loja-virtual","rastreamento-e-relatorio"]}', true);

const OLORIN_WHATSAPP_SITE_PADRAO = '5541996460861';
const OLORIN_DDDS = array(11, 12, 13, 14, 15, 16, 17, 18, 19, 21, 22, 24, 27, 28, 31, 32, 33, 34, 35, 37, 38, 41, 42, 43, 44, 45, 46, 47, 48, 49, 51, 53, 54, 55, 61, 62, 63, 64, 65, 66, 67, 68, 69, 71, 73, 74, 75, 77, 79, 81, 82, 83, 84, 85, 86, 87, 88, 89, 91, 92, 93, 94, 95, 96, 97, 98, 99);

/* ---------- Configuração ---------- */

function olorin_config()
{
	$padrao = array(
		'email_destino'    => 'digital@olorin.com.br',
		'whatsapp'         => OLORIN_WHATSAPP_SITE_PADRAO,
		'smtp_host'        => 'email-ssl.com.br',
		'smtp_porta'       => 465,
		'smtp_seguranca'   => 'ssl',
		'smtp_usuario'     => '',
		'smtp_senha'       => '',
		'remetente_nome'   => 'Site Olorin',
		'dominios'         => array('olorin.com.br', 'www.olorin.com.br'),
		'pasta_leads'      => '',
		'lead_webhook_url' => '',
		'servicos'         => array(),
	);
	$candidatos = array(dirname(__DIR__) . '/olorin-config.php', __DIR__ . '/config.php');
	foreach ($candidatos as $arquivo) {
		if (@is_readable($arquivo)) {
			$cfg = require $arquivo;
			if (is_array($cfg)) {
				$cfg = array_merge($padrao, $cfg);
				if ('TROCAR_NO_SERVIDOR' === $cfg['smtp_senha']) {
					$cfg['smtp_senha'] = '';
				}
				return $cfg;
			}
		}
	}
	return $padrao;
}

$cfg  = olorin_config();
$ajax = isset($_SERVER['HTTP_ACCEPT']) && false !== strpos((string) $_SERVER['HTTP_ACCEPT'], 'application/json');

/* ---------- Respostas ---------- */

function olorin_responder($ok, $status = 200, $extra = array())
{
	global $ajax;
	if ($ajax) {
		http_response_code($status);
		header('Content-Type: application/json; charset=utf-8');
		echo json_encode(array_merge(array('ok' => $ok), $extra), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
		exit;
	}
	if ($ok) {
		header('Location: /obrigado/', true, 303);
		exit;
	}
	olorin_pagina_erro($status, isset($extra['message']) ? $extra['message'] : '', isset($extra['fields']) ? $extra['fields'] : array());
}

/** Página simples de erro para quem envia sem JavaScript (antes voltava sem nenhuma mensagem). */
function olorin_pagina_erro($status, $mensagem, $campos)
{
	http_response_code($status);
	header('Content-Type: text/html; charset=utf-8');
	$h = static function ($t) {
		return htmlspecialchars((string) $t, ENT_QUOTES, 'UTF-8');
	};
	$voltar = '/#orcamento';
	if (!empty($_SERVER['HTTP_REFERER']) && olorin_mesmo_dominio($_SERVER['HTTP_REFERER'])) {
		$voltar = strtok((string) $_SERVER['HTTP_REFERER'], '#') . '#orcamento';
	}
	$wa = 'https://wa.me/' . OLORIN_WHATSAPP_SITE_PADRAO . '?text=' . rawurlencode('Oi! Tentei pedir um orçamento pelo site da Olorin e não consegui. [ref: form-erro-sem-js]');
	echo '<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex">';
	echo '<title>Não conseguimos enviar | Olorin Digital</title>';
	echo '<style>body{margin:0;background:#7e3bed;color:#fff;font:16px/1.6 ui-monospace,Menlo,Consolas,monospace}main{max-width:620px;margin:10vh auto;padding:24px;border:2px solid #fff;background:rgba(0,0,0,.18)}h1{font:900 28px/1.1 "Arial Black",sans-serif;text-transform:uppercase;margin:0 0 12px}a{color:#fff;font-weight:700}li{margin:4px 0}.b{display:inline-block;margin:16px 12px 0 0;padding:14px 18px;border:2px solid #fff;text-decoration:none}.b:first-of-type{background:#fff;color:#7e3bed}</style></head><body><main>';
	echo '<h1>Não conseguimos enviar</h1><p>' . $h($mensagem ? $mensagem : 'Confira os dados e tente de novo.') . '</p>';
	if ($campos) {
		echo '<ul>';
		foreach ($campos as $texto) {
			echo '<li>' . $h($texto) . '</li>';
		}
		echo '</ul>';
	}
	echo '<a class="b" href="' . $h($voltar) . '">Voltar ao formulário</a><a class="b" href="' . $h($wa) . '">Chamar no WhatsApp</a>';
	echo '</main></body></html>';
	exit;
}

/* ---------- Utilidades ---------- */

/** Texto de UMA linha: sem tags, sem caracteres de controle, sem quebra de linha (evita injeção de cabeçalho). */
function olorin_linha($chave, $max = 200)
{
	$v = isset($_POST[$chave]) && is_scalar($_POST[$chave]) ? (string) $_POST[$chave] : '';
	$v = strip_tags($v);
	$v = preg_replace('/[\x00-\x1F\x7F]+/u', ' ', $v);
	$v = trim(preg_replace('/\s{2,}/u', ' ', (string) $v));
	return function_exists('mb_substr') ? mb_substr($v, 0, $max) : substr($v, 0, $max);
}

/** Texto de várias linhas (mensagem): mantém as quebras, tira o resto. */
function olorin_texto($chave, $max = 1500)
{
	$v = isset($_POST[$chave]) && is_scalar($_POST[$chave]) ? (string) $_POST[$chave] : '';
	$v = strip_tags($v);
	$v = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $v);
	$v = trim(str_replace("\r\n", "\n", (string) $v));
	return function_exists('mb_substr') ? mb_substr($v, 0, $max) : substr($v, 0, $max);
}

function olorin_permitido($valor, $lista)
{
	return in_array($valor, $lista, true) ? $valor : '';
}

function olorin_host($url)
{
	$host = parse_url((string) $url, PHP_URL_HOST);
	return $host ? strtolower($host) : '';
}

/** O pedido veio do próprio site? (aceita os domínios da config e o host atual, para testes locais) */
function olorin_mesmo_dominio($url)
{
	global $cfg;
	$host = olorin_host($url);
	if ('' === $host) {
		return false;
	}
	$atual = strtolower(preg_replace('/:\d+$/', '', isset($_SERVER['HTTP_HOST']) ? (string) $_SERVER['HTTP_HOST'] : ''));
	$aceitos = array_merge(array_map('strtolower', (array) $cfg['dominios']), array($atual));
	return in_array($host, $aceitos, true);
}

/** WhatsApp: só dígitos, DDD válido, celular com 9 → +55DDDNÚMERO (ou '' se inválido). */
function olorin_whatsapp($bruto, &$erro)
{
	$d = preg_replace('/\D+/', '', (string) $bruto);
	if (strlen($d) > 11 && 0 === strpos($d, '55')) {
		$d = substr($d, 2);
	}
	if (strlen($d) < 10 || strlen($d) > 11) {
		$erro = 'Confira o WhatsApp com DDD, por exemplo (41) 99999-9999.';
		return '';
	}
	if (!in_array((int) substr($d, 0, 2), OLORIN_DDDS, true)) {
		$erro = 'Esse DDD não existe. Confira o número.';
		return '';
	}
	if (11 === strlen($d) && '9' !== $d[2]) {
		$erro = 'Confira o WhatsApp com DDD, por exemplo (41) 99999-9999.';
		return '';
	}
	return '+55' . $d;
}

/* ---------- 1. Método, origem e anti-spam ---------- */

if ('POST' !== (isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : '')) {
	http_response_code(405);
	header('Allow: POST');
	exit('Método não permitido.');
}

$origem_http = isset($_SERVER['HTTP_ORIGIN']) ? (string) $_SERVER['HTTP_ORIGIN'] : '';
$referer     = isset($_SERVER['HTTP_REFERER']) ? (string) $_SERVER['HTTP_REFERER'] : '';
if (('' !== $origem_http && 'null' !== $origem_http && !olorin_mesmo_dominio($origem_http))
	|| ('' === $origem_http && '' !== $referer && !olorin_mesmo_dominio($referer))) {
	olorin_responder(false, 403, array('message' => 'Envio recusado: origem desconhecida.'));
}

// Isca para robôs: responde "ok" sem gravar nada.
if (!empty($_POST['empresa_url'])) {
	olorin_responder(true, 200, array('redirect' => '/obrigado/'));
}

// Tempo mínimo de preenchimento (3 s). olorin_tempo = segundos (JS); olorin_ts = carimbo de quando o formulário abriu.
$tempo = null;
if (isset($_POST['olorin_tempo']) && is_numeric($_POST['olorin_tempo']) && '' !== $_POST['olorin_tempo']) {
	$tempo = (int) $_POST['olorin_tempo'];
} elseif (isset($_POST['olorin_ts']) && ctype_digit((string) $_POST['olorin_ts'])) {
	$ts = (int) $_POST['olorin_ts'];
	if ($ts > time() - 2 * 86400 && $ts <= time() + 60) {
		$tempo = time() - $ts;
	}
}
if (null !== $tempo && $tempo < 3) {
	olorin_responder(false, 429, array('message' => 'Envio rápido demais. Espere alguns segundos e tente de novo.'));
}

/* ---------- 2. Dados ---------- */

$erro_whats = '';
$lead = array(
	'data'                => date('d/m/Y H:i'),
	'nome'                => olorin_linha('nome', 80),
	'whatsapp'            => olorin_whatsapp(olorin_linha('whatsapp', 30), $erro_whats),
	'site'                => olorin_linha('site', 120),
	'servicos'            => '',
	'investimento'        => olorin_permitido(olorin_linha('investimento', 80), $OLORIN_LISTAS['investimento']),
	'mensagem'            => olorin_texto('mensagem', 1500),
	'plano'               => olorin_permitido(olorin_linha('plano', 40), $OLORIN_LISTAS['planos']),
	'utm_source'          => olorin_linha('utm_source', 120),
	'utm_medium'          => olorin_linha('utm_medium', 120),
	'utm_campaign'        => olorin_linha('utm_campaign', 160),
	'utm_content'         => olorin_linha('utm_content', 160),
	'utm_term'            => olorin_linha('utm_term', 160),
	'gclid'               => olorin_linha('gclid', 255),
	'gbraid'              => olorin_linha('gbraid', 255),
	'wbraid'              => olorin_linha('wbraid', 255),
	'fbclid'              => olorin_linha('fbclid', 255),
	'primeiro_toque'      => olorin_linha('primeiro_toque', 500),
	'pagina'              => olorin_linha('pagina', 300),
	'referencia'          => olorin_linha('referencia', 300),
	'modo_pagina'         => olorin_permitido(olorin_linha('modo_pagina', 20), array('home', 'servico', 'promo', 'sobre', 'hub', 'simples', 'obrigado', 'erro')),
	'servico_pagina'      => olorin_permitido(olorin_linha('servico_pagina', 60), $OLORIN_LISTAS['slugs']),
	'posicao_formulario'  => olorin_permitido(olorin_linha('posicao_formulario', 10), array('topo', 'fim', 'promo')),
	'variante_formulario' => olorin_permitido(olorin_linha('variante_formulario', 2), array('a', 'b')),
	'consentimento'       => !empty($_POST['consentimento']) ? date('d/m/Y H:i') : '',
	'email_enviado'       => '',
);
if (isset($_POST['servicos']) && is_array($_POST['servicos'])) {
	$aceitos = array_merge($OLORIN_LISTAS['servicos'], (array) $cfg['servicos']);
	$lead['servicos'] = implode(', ', array_values(array_intersect(array_map('strval', $_POST['servicos']), $aceitos)));
}

$erros = array();
if ((function_exists('mb_strlen') ? mb_strlen($lead['nome']) : strlen($lead['nome'])) < 2) {
	$erros['nome'] = 'Conta pra gente o seu nome.';
}
if ('' === $lead['whatsapp']) {
	$erros['whatsapp'] = $erro_whats;
}
if ('' === $lead['consentimento']) {
	$erros['consentimento'] = 'Precisamos do seu ok para entrar em contato.';
}
if ($erros) {
	olorin_responder(false, 422, array('message' => 'Confira os campos destacados.', 'fields' => $erros));
}

/* ---------- 3. Limite por IP (só pedidos válidos contam) ---------- */

$ip       = isset($_SERVER['REMOTE_ADDR']) ? (string) $_SERVER['REMOTE_ADDR'] : '';
$rl_file  = sys_get_temp_dir() . '/olorin_rl_' . hash('sha256', $ip . __DIR__);
$envios   = @is_readable($rl_file) ? array_filter(array_map('intval', explode(',', (string) @file_get_contents($rl_file)))) : array();
$envios   = array_values(array_filter($envios, static function ($t) {
	return $t > time() - 600;
}));
if (count($envios) >= 6) {
	olorin_responder(false, 429, array('message' => 'Muitos envios seguidos. Chame a gente no WhatsApp.'));
}
$envios[] = time();
@file_put_contents($rl_file, implode(',', $envios), LOCK_EX);

/* ---------- 4. CSV mensal fora da pasta pública ---------- */

function olorin_pasta_leads()
{
	global $cfg;
	$opcoes = array_filter(array($cfg['pasta_leads'], dirname(__DIR__) . '/leads', __DIR__ . '/leads'));
	foreach ($opcoes as $pasta) {
		if (!is_dir($pasta)) {
			@mkdir($pasta, 0750, true);
		}
		if (is_dir($pasta) && is_writable($pasta)) {
			if (0 === strpos(realpath($pasta), realpath(__DIR__))) {
				// Dentro do site: garante o bloqueio de acesso.
				if (!file_exists($pasta . '/.htaccess')) {
					@file_put_contents($pasta . '/.htaccess', "Require all denied\n");
				}
			}
			return $pasta;
		}
	}
	return '';
}

/** "+5541999990000" → "(41) 99999-0000" (o Excel não confunde com número nem com fórmula). */
function olorin_whatsapp_legivel($e164)
{
	$d = preg_replace('/\D/', '', (string) $e164);
	if (0 === strpos($d, '55') && strlen($d) > 11) {
		$d = substr($d, 2);
	}
	if (11 === strlen($d)) {
		return '(' . substr($d, 0, 2) . ') ' . substr($d, 2, 5) . '-' . substr($d, 7);
	}
	if (10 === strlen($d)) {
		return '(' . substr($d, 0, 2) . ') ' . substr($d, 2, 4) . '-' . substr($d, 6);
	}
	return $d;
}

/** Linha da planilha: WhatsApp legível + link clicável para abrir a conversa. */
function olorin_para_planilha($lead)
{
	$saida = array();
	foreach ($lead as $chave => $valor) {
		if ('whatsapp' === $chave) {
			$saida['whatsapp']      = olorin_whatsapp_legivel($valor);
			$saida['whatsapp_link'] = '' !== $valor ? 'https://wa.me/' . ltrim($valor, '+') : '';
		} else {
			$saida[$chave] = $valor;
		}
	}
	return $saida;
}

function olorin_gravar_csv($lead)
{
	$lead  = olorin_para_planilha($lead);
	$pasta = olorin_pasta_leads();
	if ('' === $pasta) {
		return false;
	}
	$arquivo = $pasta . '/' . date('Y-m') . '.csv';
	$novo    = !file_exists($arquivo);
	$h       = @fopen($arquivo, 'a');
	if (!$h) {
		return false;
	}
	flock($h, LOCK_EX);
	if ($novo) {
		fwrite($h, "\xEF\xBB\xBF");
		fputcsv($h, array_keys($lead), ';');
	}
	$linha = array_map(static function ($v) {
		$v = (string) $v;
		// Protege contra injeção de fórmula no Excel/Planilhas.
		return ('' !== $v && in_array($v[0], array('=', '+', '-', '@', "\t", "\r"), true)) ? "'" . $v : $v;
	}, array_values($lead));
	$ok = false !== fputcsv($h, $linha, ';');
	flock($h, LOCK_UN);
	fclose($h);
	return $ok;
}

/* ---------- 5. E-mail e webhook ---------- */

$rotulos = array(
	'nome' => 'Nome', 'whatsapp' => 'WhatsApp', 'site' => 'Site / Instagram', 'servicos' => 'Precisa de',
	'investimento' => 'Investimento em anúncio', 'mensagem' => 'Mensagem', 'plano' => 'Plano clicado',
	'servico_pagina' => 'Página de serviço', 'modo_pagina' => 'Tipo de página', 'posicao_formulario' => 'Formulário',
	'variante_formulario' => 'Variante (A/B)', 'utm_source' => 'utm_source', 'utm_medium' => 'utm_medium',
	'utm_campaign' => 'utm_campaign', 'utm_content' => 'utm_content', 'utm_term' => 'utm_term',
	'gclid' => 'gclid', 'gbraid' => 'gbraid', 'wbraid' => 'wbraid', 'fbclid' => 'fbclid',
	'primeiro_toque' => 'Primeiro toque', 'pagina' => 'Página de envio', 'referencia' => 'Veio de',
	'consentimento' => 'Consentimento LGPD',
);

$assunto_o_que = $lead['plano'] ? 'plano ' . $lead['plano'] : ($lead['servicos'] ? $lead['servicos'] : 'orçamento');
if ($lead['utm_source']) {
	$assunto_origem = $lead['utm_source'] . ($lead['utm_medium'] ? '/' . $lead['utm_medium'] : '');
} elseif ($lead['gclid'] || $lead['gbraid'] || $lead['wbraid']) {
	$assunto_origem = 'google ads';
} elseif ($lead['fbclid']) {
	$assunto_origem = 'meta';
} elseif ($lead['referencia']) {
	$assunto_origem = olorin_host($lead['referencia']) ?: 'indicação';
} else {
	$assunto_origem = 'site (direto)';
}
$assunto = 'Novo lead: ' . (function_exists('mb_substr') ? mb_substr($assunto_o_que, 0, 80) : substr($assunto_o_que, 0, 80)) . ' | ' . $assunto_origem;

$corpo = '';
foreach ($rotulos as $chave => $rotulo) {
	if ('' !== $lead[$chave]) {
		$corpo .= $rotulo . ': ' . $lead[$chave] . "\n";
	}
}
$corpo .= "\nResponder no WhatsApp: https://wa.me/" . ltrim($lead['whatsapp'], '+') . "\n";

$erro_email = '';
$enviado    = olorin_enviar_email($cfg, (string) $cfg['email_destino'], $assunto, $corpo, $erro_email);
$lead['email_enviado'] = $enviado ? 'sim' : 'não';
$salvo = olorin_gravar_csv($lead);

if (!empty($cfg['lead_webhook_url']) && preg_match('#^https://#', (string) $cfg['lead_webhook_url'])) {
	$ctx = stream_context_create(array('http' => array(
		'method'        => 'POST',
		'header'        => "Content-Type: application/json\r\n",
		'content'       => json_encode($lead, JSON_UNESCAPED_UNICODE),
		'timeout'       => 3,
		'ignore_errors' => true,
	)));
	@file_get_contents((string) $cfg['lead_webhook_url'], false, $ctx); // falha silenciosa
}

if (!$salvo && !$enviado) {
	error_log('Olorin: pedido não registrado (sem CSV e sem e-mail). ' . $erro_email);
	olorin_responder(false, 500, array('message' => 'Não conseguimos registrar agora.'));
}
if (!$enviado) {
	error_log('Olorin: pedido salvo no CSV, mas o e-mail falhou. ' . $erro_email);
}

olorin_responder(true, 200, array(
	'message'  => 'Recebido.',
	'redirect' => '/obrigado/',
	'whatsapp' => 'https://wa.me/' . OLORIN_WHATSAPP_SITE_PADRAO . '?text=' . rawurlencode('Oi! Acabei de pedir um orçamento pelo site da Olorin e quero adiantar a conversa. [ref: obrigado]'),
));

/**
 * E-mail: SMTP autenticado se configurado (exigência da Locaweb); senão tenta mail() do PHP.
 */
function olorin_enviar_email($cfg, $para, $assunto, $corpo, &$erro)
{
	if ('' === trim($para)) {
		$erro = 'sem e-mail de destino';
		return false;
	}
	if (empty($cfg['smtp_usuario']) || empty($cfg['smtp_senha'])) {
		$host = preg_replace('/^www\./', '', preg_replace('/[^a-z0-9.-]/i', '', isset($_SERVER['HTTP_HOST']) ? (string) $_SERVER['HTTP_HOST'] : 'localhost'));
		$de   = 'no-reply@' . $host;
		$ok   = function_exists('mail') && @mail($para, '=?UTF-8?B?' . base64_encode($assunto) . '?=', $corpo, 'From: ' . $de . "\r\nContent-Type: text/plain; charset=UTF-8", '-f' . $de);
		$erro = $ok ? '' : 'mail() indisponível — configure o SMTP';
		return $ok;
	}
	return olorin_smtp($cfg, $para, $assunto, $corpo, $erro);
}

/**
 * Cliente SMTP mínimo (SSL na 465 ou STARTTLS na 587) com AUTH LOGIN e tempo limite curto.
 */
function olorin_smtp($cfg, $para, $assunto, $corpo, &$erro)
{
	$seguranca = strtolower((string) $cfg['smtp_seguranca']);
	$remoto    = ('ssl' === $seguranca ? 'ssl://' : 'tcp://') . $cfg['smtp_host'] . ':' . (int) $cfg['smtp_porta'];
	$ctx       = stream_context_create(array('ssl' => array('verify_peer' => true, 'verify_peer_name' => true, 'SNI_enabled' => true)));
	$fp        = @stream_socket_client($remoto, $errno, $errstr, 10, STREAM_CLIENT_CONNECT, $ctx);
	if (!$fp) {
		$erro = 'Conexão SMTP falhou: ' . $errstr;
		return false;
	}
	stream_set_timeout($fp, 10);

	$falar = static function ($comando, $espera) use ($fp, &$erro) {
		if (null !== $comando) {
			fwrite($fp, $comando . "\r\n");
		}
		$resposta = '';
		while (false !== ($linha = fgets($fp, 1024))) {
			$resposta .= $linha;
			if (strlen($linha) < 4 || ' ' === $linha[3]) {
				break;
			}
		}
		$meta = stream_get_meta_data($fp);
		if (!empty($meta['timed_out'])) {
			$erro = 'tempo esgotado no SMTP';
			return false;
		}
		if (!in_array((int) substr($resposta, 0, 3), (array) $espera, true)) {
			$erro = trim($resposta) ? trim($resposta) : 'sem resposta do servidor';
			return false;
		}
		return true;
	};

	$host = preg_replace('/[^a-z0-9.-]/i', '', isset($_SERVER['HTTP_HOST']) ? (string) $_SERVER['HTTP_HOST'] : 'localhost');
	$de   = (string) $cfg['smtp_usuario'];
	$ok   = $falar(null, 220) && $falar('EHLO ' . $host, 250);
	if ($ok && 'tls' === $seguranca) {
		$ok = $falar('STARTTLS', 220)
			&& stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)
			&& $falar('EHLO ' . $host, 250);
	}
	$ok = $ok
		&& $falar('AUTH LOGIN', 334)
		&& $falar(base64_encode($de), 334)
		&& $falar(base64_encode((string) $cfg['smtp_senha']), 235)
		&& $falar('MAIL FROM:<' . $de . '>', 250)
		&& $falar('RCPT TO:<' . $para . '>', array(250, 251))
		&& $falar('DATA', 354);

	if ($ok) {
		$cod = static function ($t) {
			return '=?UTF-8?B?' . base64_encode($t) . '?=';
		};
		$msg = 'Date: ' . date('r') . "\r\n"
			. 'From: ' . $cod((string) $cfg['remetente_nome']) . ' <' . $de . ">\r\n"
			. 'To: <' . $para . ">\r\n"
			. 'Subject: ' . $cod($assunto) . "\r\n"
			. 'Message-ID: <' . bin2hex(random_bytes(8)) . '@' . $host . ">\r\n"
			. "MIME-Version: 1.0\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n"
			. chunk_split(base64_encode($corpo));
		fwrite($fp, $msg . "\r\n.\r\n");
		$ok = $falar(null, 250);
	}
	@fwrite($fp, "QUIT\r\n");
	fclose($fp);
	return $ok;
}

